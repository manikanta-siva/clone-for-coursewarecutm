<?php
session_start();
if (isset($_SESSION['username'])) {
    // User is logged in, add their session ID to the list of active sessions
    $sessionId = session_id();
    $activeSessions = json_decode(file_get_contents('active_sessions.json'), true);
    $activeSessions[$sessionId] = time();
    file_put_contents('active_sessions.json', json_encode($activeSessions));

    // Display the number of users online
    $numUsersOnline = count($activeSessions);
    echo $numUsersOnline;
} else {
    // User is not logged in, return 0
    echo 0;
}
?>
