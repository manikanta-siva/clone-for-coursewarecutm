<?php
session_start();

// Check if user is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Connect to database
    $con = mysqli_connect("localhost", "root", "", "awp");

    // Delete sessions older than 5 minutes
    $timeout = 300; // 5 minutes
    $query = "DELETE FROM online_users WHERE timestamp < '".(time()-$timeout)."'";
    mysqli_query($con, $query);

    // Store current session in database
    $query = "REPLACE INTO online_users (user_id, timestamp) VALUES ('$user_id', '".time()."')";
    mysqli_query($con, $query);

    // Get number of online users
    $query = "SELECT COUNT(*) FROM online_users";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_row($result);
    $num_online = $row[0];

    echo "Number of users online: ".$num_online;

    // Close database connection
    mysqli_close($con);
} else {
    echo "Please login to see online users.";
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="img/cutm.png">
    <title>COURSEWARE CUTM</title>

    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>    