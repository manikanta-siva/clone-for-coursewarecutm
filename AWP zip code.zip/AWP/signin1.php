<?php
// Start the session
session_start();

// Initialize variables for form fields
$username = "";
$password = "";
$errorMessage = "";

// Check if the login form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Check if the credentials are valid (dummy example)
    if ($username === "username" && $password === "password") {
        // Set session variables
        $_SESSION["username"] = $username;
        $_SESSION["loggedin"] = true;

        // Redirect to a secure page
        header("Location: secure_page.php");
        exit;
    } else {
        $errorMessage = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" value="<?php echo $username; ?>">
        <br>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password">
        <br>
        <input type="submit" value="Login">
    </form>
    <p><?php echo $errorMessage; ?></p>
</body>
</html>
